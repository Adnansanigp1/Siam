package com.angina.app.ui

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Figma frame width. Frame is 412 x 917, the page scrolls vertically. */
const val DESIGN_WIDTH = 412f

/**
 * Makes 1dp == 1 Figma unit on every phone: the screen width is always exactly 412dp.
 * (Font scale is pinned to 1 so text keeps the same proportions as the design.)
 */
@Composable
fun FixedDesignScale(content: @Composable () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = Density(density = constraints.maxWidth / DESIGN_WIDTH, fontScale = 1f)
        CompositionLocalProvider(LocalDensity provides density) { content() }
    }
}

object AppColors {
    val Brand = Color(0xFF3B5998)
    val Link = Color(0xFF1877F2)
    val Dark = Color(0xFF222222)
    val Gray = Color(0xFF6B7280)
    val IconGray = Color(0xFF5C5F63)
    val DividerLight = Color(0xFFE5E5E5)
    val DividerThick = Color(0xFFD9D9D9)
    val Surface = Color(0xFFF1F2F6)
}

/** Android's sans-serif is Roboto, same family as the design. */
val AppFont: FontFamily = FontFamily.SansSerif

fun Modifier.at(x: Float, y: Float): Modifier = this.offset(x.dp, y.dp)

fun textStyle(
    size: Float,
    lineHeight: Float,
    color: Color,
    weight: FontWeight = FontWeight.Normal,
    align: TextAlign = TextAlign.Unspecified,
) = TextStyle(
    color = color,
    fontSize = size.sp,
    fontWeight = weight,
    fontFamily = AppFont,
    lineHeight = lineHeight.sp,
    textAlign = align,
    platformStyle = PlatformTextStyle(includeFontPadding = false),
    lineHeightStyle = LineHeightStyle(
        alignment = LineHeightStyle.Alignment.Center,
        trim = LineHeightStyle.Trim.None,
    ),
)

/** Distance from the top of a text line box to its baseline (Roboto metrics). */
fun baselineInLine(size: Float, lineHeight: Float) = lineHeight / 2f + 0.3418f * size

/** Single-line text placed by its *baseline* so it matches the Figma coordinates exactly. */
@Composable
fun BText(
    text: String,
    x: Float,
    baseline: Float,
    size: Float,
    color: Color,
    weight: FontWeight = FontWeight.Normal,
    lineHeight: Float = 20f,
) {
    BasicText(
        text = text,
        modifier = Modifier.at(x, baseline - baselineInLine(size, lineHeight)),
        style = textStyle(size, lineHeight, color, weight),
        maxLines = 1,
        softWrap = false,
    )
}

@Composable
fun DIcon(
    @DrawableRes res: Int,
    modifier: Modifier = Modifier,
    w: Float = 24f,
    h: Float = w,
    tint: Color = Color.Unspecified,
) {
    Image(
        painter = painterResource(res),
        contentDescription = null,
        modifier = modifier.size(w.dp, h.dp),
        colorFilter = if (tint == Color.Unspecified) null else ColorFilter.tint(tint),
    )
}
