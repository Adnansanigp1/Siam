package com.angina.app.ui

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color
import com.angina.app.R

data class Story(val name: String, @DrawableRes val cover: Int, @DrawableRes val avatar: Int)

sealed interface PostActions {
    /** "👍 7K  💬 137  ↗ 87  Send" row (first post). */
    data class Counts(val like: String, val comment: String, val share: String) : PostActions

    /** "Like  Comment  Send" row. */
    data object Labels : PostActions
}

sealed interface FeedItem {
    val id: String
}

data class PostItem(
    override val id: String,
    val author: String,
    @DrawableRes val avatar: Int,
    val verified: Boolean,
    val closable: Boolean,
    val time: String,
    val text: String,
    val hashtag: String,
    val hashtagColor: Color,
    @DrawableRes val image: Int,
    val reactions: String,
    val stats: List<String>,
    val actions: PostActions,
) : FeedItem

data object ReelsItem : FeedItem {
    override val id = "reels"
}

object SampleData {
    private const val BODY = "Spring brights, all sustainable! every shown was made before 1982,except the"

    val stories = listOf(
        Story("Itz. Khaled", R.drawable.story_khaled, R.drawable.story_avatar_khaled),
        Story("Tamim Islam", R.drawable.story_tamim, R.drawable.story_avatar_tamim),
        Story("Samim Islam", R.drawable.story_samim, R.drawable.story_avatar_samim),
        Story("Samima Akter", R.drawable.story_samima, R.drawable.story_avatar_samima),
        Story("KAMAL", R.drawable.story_kamal, R.drawable.story_avatar_kamal),
        Story("MS. Santa", R.drawable.story_santa, R.drawable.story_avatar_santa),
    )

    val reels = listOf(
        R.drawable.reel_1, R.drawable.reel_2, R.drawable.reel_3, R.drawable.reel_4,
        R.drawable.reel_5, R.drawable.reel_6, R.drawable.reel_7,
    )

    val feed: List<FeedItem> = listOf(
        PostItem(
            id = "khaled", author = "Itz. Khaled", avatar = R.drawable.avatar_khaled,
            verified = true, closable = true, time = "1h",
            text = BODY, hashtag = "#vintage", hashtagColor = AppColors.Brand,
            image = R.drawable.post_khaled, reactions = "38K",
            stats = listOf("1k comment", "5.3k shares", "946k views"),
            actions = PostActions.Counts("7K", "137", "87"),
        ),
        PostItem(
            id = "hasna", author = "Hasna-Hena", avatar = R.drawable.avatar_hasna,
            verified = false, closable = false, time = "3h",
            text = BODY, hashtag = "#vintage", hashtagColor = AppColors.Link,
            image = R.drawable.post_hasna, reactions = "38K",
            stats = listOf("13 comment", "5 shares", "94 views"),
            actions = PostActions.Labels,
        ),
        ReelsItem,
        PostItem(
            id = "santa", author = "MS. Santa", avatar = R.drawable.avatar_santa,
            verified = false, closable = false, time = "5h",
            text = BODY, hashtag = "#vintage", hashtagColor = AppColors.Link,
            image = R.drawable.post_santa, reactions = "38K",
            stats = listOf("9 comment", "1k views"),
            actions = PostActions.Labels,
        ),
        PostItem(
            id = "samim", author = "Samim Islam", avatar = R.drawable.avatar_samim,
            verified = false, closable = false, time = "9h",
            text = BODY, hashtag = "#vintage", hashtagColor = AppColors.Link,
            image = R.drawable.post_samim, reactions = "38K",
            stats = listOf("367 comment", "900 views"),
            actions = PostActions.Labels,
        ),
    )
}
