package com.angina.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.angina.app.R

// All numbers below are Figma units (frame 412 wide) == dp, see FixedDesignScale.

@Composable
fun HomeScreen() {
    var selectedTab by remember { mutableIntStateOf(0) }
    val feed = remember { mutableStateListOf<FeedItem>().apply { addAll(SampleData.feed) } }
    val liked = remember { mutableStateMapOf<String, Boolean>() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding(),
    ) {
        TopBar()
        TabBar(selectedTab) { selectedTab = it }
        if (selectedTab == 0) {
            HomeFeed(
                feed = feed,
                liked = liked,
                onClose = { id -> feed.removeAll { it.id == id } },
            )
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                BasicText("Coming soon", style = textStyle(16f, 24f, AppColors.Gray))
            }
        }
    }
}

// ───────────────────────── Top bar (y 24 → 80) ─────────────────────────

@Composable
private fun TopBar() {
    Box(Modifier.fillMaxWidth().height(56.dp)) {
        DIcon(R.drawable.ic_logo, Modifier.at(16.1f, 19.4f), w = 75f, h = 23f)
        DIcon(R.drawable.ic_add_circle, Modifier.at(266f, 17f))
        DIcon(R.drawable.ic_bell, Modifier.at(310f, 17f))
        DIcon(R.drawable.ic_search, Modifier.at(353.5f, 16.5f))
    }
}

// ───────────────────────── Tab bar (y 80 → 128) ─────────────────────────

private val tabIcons = listOf(
    R.drawable.ic_tab_home,
    R.drawable.ic_tab_friends,
    R.drawable.ic_tab_video,
    R.drawable.ic_tab_emoji,
    R.drawable.ic_tab_menu,
)

@Composable
private fun TabBar(selected: Int, onSelect: (Int) -> Unit) {
    Box(Modifier.fillMaxWidth().height(48.dp)) {
        Row(Modifier.padding(horizontal = 6.dp)) {
            tabIcons.forEachIndexed { index, icon ->
                val isSelected = index == selected
                Box(
                    Modifier
                        .width(80.dp)
                        .height(48.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) { onSelect(index) },
                    contentAlignment = Alignment.Center,
                ) {
                    DIcon(
                        icon,
                        Modifier.at(0f, -0.5f),
                        tint = if (isSelected) AppColors.Brand else AppColors.Dark,
                    )
                    if (isSelected) {
                        Box(
                            Modifier
                                .align(Alignment.BottomCenter)
                                .width(70.dp)
                                .height(3.dp)
                                .clip(RoundedCornerShape(1.5.dp))
                                .background(AppColors.Brand),
                        )
                    }
                }
            }
        }
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .height(1.dp)
                .background(AppColors.DividerLight),
        )
    }
}


// ───────────────────────── Feed ─────────────────────────

@Composable
private fun HomeFeed(
    feed: List<FeedItem>,
    liked: MutableMap<String, Boolean>,
    onClose: (String) -> Unit,
) {
    LazyColumn(Modifier.fillMaxSize()) {
        item(key = "composer") { Composer() }
        item(key = "sep-composer") { Separator(3f, AppColors.DividerLight) }
        item(key = "stories") { StoriesRow() }
        item(key = "sep-stories") { Separator(3f, AppColors.DividerLight) }

        items(feed, key = { it.id }) { item ->
            when (item) {
                is PostItem -> {
                    PostCard(
                        post = item,
                        dividerColor = if (item.closable) AppColors.DividerLight else AppColors.DividerThick,
                        liked = liked[item.id] == true,
                        onLike = { liked[item.id] = liked[item.id] != true },
                        onClose = { onClose(item.id) },
                    )
                    Separator(3f, AppColors.DividerThick)
                }
                is ReelsItem -> {
                    ReelsSection()
                    Separator(3f, AppColors.DividerThick)
                }
            }
        }
        item(key = "bottom") { Spacer(Modifier.navigationBarsPadding().height(16.dp)) }
    }
}

@Composable
private fun Separator(height: Float, color: Color) {
    Box(Modifier.fillMaxWidth().height(height.dp).background(color))
}

// ───────────────────────── "What's on your mind?" (y 128 → 198) ─────────────────────────

@Composable
private fun Composer() {
    Box(Modifier.fillMaxWidth().height(70.dp)) {
        Image(
            painterResource(R.drawable.avatar_me), null,
            Modifier.at(16f, 15f).size(40.dp).clip(CircleShape),
            contentScale = ContentScale.Crop,
        )
        Box(
            Modifier
                .at(76f, 15f)
                .size(270.dp, 40.dp)
                .border(1.dp, AppColors.Gray, RoundedCornerShape(20.dp)),
        )
        BText("What's on Your mind?", x = 96.3f, baseline = 40f, size = 16f, color = AppColors.Gray)
        DIcon(R.drawable.ic_gallery, Modifier.at(366f, 23f))
    }
}

// ───────────────────────── Stories (y 201 → 391) ─────────────────────────

@Composable
private fun StoriesRow() {
    LazyRow(
        modifier = Modifier.fillMaxWidth().height(190.dp),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 15.dp, bottom = 15.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "create") { CreateStoryCard() }
        items(SampleData.stories, key = { it.name }) { StoryCard(it) }
    }
}

@Composable
private fun CreateStoryCard() {
    Box(
        Modifier
            .size(110.dp, 160.dp)
            .clip(RoundedCornerShape(5.dp))
            .background(AppColors.Surface),
    ) {
        Image(
            painterResource(R.drawable.story_create), null,
            Modifier.size(110.dp, 95.dp),
            contentScale = ContentScale.Crop,
        )
        // white ring + blue "+" button, centre (53, 95)
        Box(Modifier.at(38f, 80f).size(30.dp).background(Color.White, CircleShape)) {
            DIcon(R.drawable.ic_add_circle, Modifier.align(Alignment.Center), w = 29.7f)
        }
        BasicText(
            "Create\nStory",
            modifier = Modifier.fillMaxWidth().at(0f, 126.1f - baselineInLine(14f, 21f)),
            style = textStyle(14f, 21f, Color.Black, align = TextAlign.Center),
        )
    }
}

@Composable
private fun StoryCard(story: Story) {
    Box(Modifier.size(110.dp, 160.dp).clip(RoundedCornerShape(5.dp))) {
        Image(
            painterResource(story.cover), null,
            Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
        Box(
            Modifier
                .at(9f, 9f)
                .size(32.dp)
                .border(2.dp, AppColors.Brand, CircleShape)
                .padding(2.dp)
                .clip(CircleShape),
        ) {
            Image(
                painterResource(story.avatar), null,
                Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
        BasicText(
            story.name,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp)
                .at(0f, 147f - baselineInLine(14f, 20f)),
            style = textStyle(14f, 20f, Color.White, align = TextAlign.Center),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

// ───────────────────────── Post (515 + 3 separator) ─────────────────────────

@Composable
private fun PostCard(
    post: PostItem,
    dividerColor: Color,
    liked: Boolean,
    onLike: () -> Unit,
    onClose: () -> Unit,
) {
    // The first post has a close (X) button, so its header shifts 10 to the right.
    val dx = if (post.closable) 10f else 0f

    Box(Modifier.fillMaxWidth().height(515.dp)) {
        // header
        Image(
            painterResource(post.avatar), null,
            Modifier.at(16f, 15f).size(40.dp).clip(CircleShape),
            contentScale = ContentScale.Crop,
        )
        Row(Modifier.at(71f + dx, 14f).height(24.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicText(
                post.author,
                style = textStyle(16f, 20f, Color.Black, FontWeight.Medium),
                maxLines = 1,
            )
            if (post.verified) DIcon(R.drawable.ic_verified, Modifier.padding(start = 8.dp))
        }
        Row(Modifier.at(71f + dx, 34.2f).height(24.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicText(post.time, style = textStyle(14f, 20f, AppColors.Gray), maxLines = 1)
            Spacer(Modifier.width(6.dp))
            Dot()
            DIcon(R.drawable.ic_globe)
        }
        DIcon(R.drawable.ic_more, Modifier.at(if (post.closable) 324f else 374f, 14f))
        if (post.closable) {
            Box(
                Modifier
                    .at(366f, 6f)
                    .size(40.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onClose,
                    ),
            ) {
                DIcon(R.drawable.ic_close, Modifier.align(Alignment.Center))
            }
        }

        // body text (16sp / 25 line height, hashtag after 5 spaces like the design)
        BasicText(
            text = buildAnnotatedString {
                append(post.text)
                append("     ")
                withStyle(SpanStyle(color = post.hashtagColor)) { append(post.hashtag) }
            },
            modifier = Modifier.at(16f, 75f).width(380.dp),
            style = textStyle(16f, 25f, Color.Black),
        )

        // photo
        Image(
            painterResource(post.image), null,
            Modifier.at(0f, 135f).fillMaxWidth().height(300.dp).clip(RoundedCornerShape(5.dp)),
            contentScale = ContentScale.Crop,
        )

        // reactions + counters
        Image(
            painterResource(R.drawable.reaction_bubbles), null,
            Modifier.at(14f, 443f).size(34.dp, 22.dp),
        )
        BText(post.reactions, x = 50.5f, baseline = 459f, size = 14f, color = AppColors.Gray)
        Row(
            Modifier.at(0f, 444.2f).fillMaxWidth().height(20.dp).padding(end = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            post.stats.forEachIndexed { i, s ->
                if (i > 0) Dot()
                BasicText(s, style = textStyle(14f, 20f, AppColors.Gray), maxLines = 1)
            }
        }
        Box(Modifier.at(0f, 470f).fillMaxWidth().height(1.dp).background(dividerColor))

        // action row
        val likeTint = if (liked) AppColors.Brand else Color.Unspecified
        val textColor = if (liked) AppColors.Brand else AppColors.IconGray
        when (val a = post.actions) {
            is PostActions.Counts -> {
                DIcon(R.drawable.ic_like, Modifier.at(15f, 480.5f), tint = likeTint)
                BText(a.like, 49f, 498.6f, 16f, textColor)
                DIcon(R.drawable.ic_comment, Modifier.at(117f, 480.5f))
                BText(a.comment, 151.3f, 498.6f, 16f, AppColors.IconGray)
                DIcon(R.drawable.ic_share, Modifier.at(226f, 480.5f))
                BText(a.share, 260.4f, 498.6f, 16f, AppColors.IconGray)
                DIcon(R.drawable.ic_send_face, Modifier.at(325.8f, 480.5f))
                BText("Send", 359.7f, 498.6f, 16f, AppColors.IconGray)
            }
            is PostActions.Labels -> {
                DIcon(R.drawable.ic_like, Modifier.at(16f, 480.5f), tint = likeTint)
                BText("Like", 50f, 498.6f, 16f, textColor)
                DIcon(R.drawable.ic_comment, Modifier.at(150f, 480.5f))
                BText("Comment", 184f, 498.6f, 16f, AppColors.IconGray)
                DIcon(R.drawable.ic_send_face, Modifier.at(325.8f, 480.5f))
                BText("Send", 359.7f, 498.6f, 16f, AppColors.IconGray)
            }
        }
        // like tap target
        Box(
            Modifier
                .at(6f, 471f)
                .size(100.dp, 44.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onLike,
                ),
        )
    }
}

@Composable
private fun Dot() {
    Box(Modifier.size(2.dp).background(AppColors.Gray, CircleShape))
}

// ───────────────────────── Reels (249 + 3 separator) ─────────────────────────

@Composable
private fun ReelsSection() {
    Box(Modifier.fillMaxWidth().height(249.dp)) {
        DIcon(R.drawable.ic_reels, Modifier.at(16f, 15f))
        BText("Reels Video", x = 45f, baseline = 32f, size = 14f, color = AppColors.Dark)
        LazyRow(
            modifier = Modifier.at(0f, 54f).fillMaxWidth().height(180.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(SampleData.reels) { res ->
                Image(
                    painterResource(res), null,
                    Modifier.size(135.dp, 180.dp).clip(RoundedCornerShape(5.dp)),
                    contentScale = ContentScale.Crop,
                )
            }
        }
    }
}
