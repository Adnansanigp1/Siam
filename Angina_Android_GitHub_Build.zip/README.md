# Angina – Home Page (Kotlin + Jetpack Compose)

Figma frame: 412 x 917 (পেজ ভার্টিক্যালি স্ক্রল করে)

## চালানোর নিয়ম
1. Android Studio (Koala বা নতুন) দিয়ে এই ফোল্ডারটা Open করো, Gradle Sync শেষ হতে দাও।
2. Emulator/ফোনে Run করো।

## কীভাবে সব মোবাইলে একই দেখায়
`ui/Design.kt` → `FixedDesignScale`: স্ক্রিনের প্রস্থ সবসময় ঠিক 412dp ধরা হয়
(density = screenWidthPx / 412, fontScale = 1)। ফলে ডিজাইনের 1 unit = 1dp,
প্রতিটা ফোনে লেআউট আনুপাতিকভাবে হুবহু এক।

## অ্যাসেট
- `res/drawable/ic_*.xml`  → SVG ফাইল থেকে নেওয়া VectorDrawable আইকন
- `res/drawable-nodpi/*`   → PNG ফাইল থেকে কেটে নেওয়া ছবি (avatar, story, post, reels)

## ফিচার
Tab বদলানো, Like টগল, প্রথম পোস্টের X দিয়ে পোস্ট সরানো, Stories/Reels হরাইজন্টাল স্ক্রল।
